"""ROUGE metric implementation for lexical similarity evaluation."""

from collections import Counter
from typing import Dict, List, Set, Tuple, Union

import nltk
from nltk.util import ngrams


class RougeMetric:
    """ROUGE metric for lexical similarity evaluation."""

    def __init__(self):
        """Initialize ROUGE metric."""
        try:
            nltk.data.find('tokenizers/punkt')
        except LookupError:
            nltk.download('punkt')

    def _tokenize(self, text: str) -> List[str]:
        """Tokenize text into words.

        Args:
            text (str): Input text

        Returns:
            List[str]: List of tokens
        """
        return nltk.word_tokenize(text.lower())

    def _get_ngrams(self, tokens: List[str], n: int) -> Counter:
        """Get n-grams from tokens.

        Args:
            tokens (List[str]): List of tokens
            n (int): N-gram size

        Returns:
            Counter: Counter of n-grams
        """
        return Counter(tuple(gram) for gram in ngrams(tokens, n))

    def _compute_rouge_n(
        self,
        candidate_tokens: List[str],
        reference_tokens: List[str],
        n: int,
    ) -> Tuple[float, float, float]:
        """Compute ROUGE-N scores.

        Args:
            candidate_tokens (List[str]): Candidate tokens
            reference_tokens (List[str]): Reference tokens
            n (int): N-gram size

        Returns:
            Tuple[float, float, float]: Precision, recall, and F1 scores
        """
        candidate_ngrams = self._get_ngrams(candidate_tokens, n)
        reference_ngrams = self._get_ngrams(reference_tokens, n)

        # Calculate overlap
        overlap_ngrams = candidate_ngrams & reference_ngrams
        overlap_count = sum(overlap_ngrams.values())

        # Calculate precision and recall
        candidate_count = sum(candidate_ngrams.values())
        reference_count = sum(reference_ngrams.values())

        precision = overlap_count / candidate_count if candidate_count > 0 else 0
        recall = overlap_count / reference_count if reference_count > 0 else 0

        # Calculate F1
        f1 = (
            2 * precision * recall / (precision + recall)
            if precision + recall > 0
            else 0
        )

        return precision, recall, f1

    def compute_scores(
        self,
        candidate: str,
        reference: str,
        rouge_types: List[int] = [1, 2],
    ) -> Dict[str, Dict[str, float]]:
        """Compute ROUGE scores for different n-gram sizes.

        Args:
            candidate (str): Candidate text
            reference (str): Reference text
            rouge_types (List[int]): List of n-gram sizes to compute

        Returns:
            Dict[str, Dict[str, float]]: Dictionary with ROUGE scores
        """
        candidate_tokens = self._tokenize(candidate)
        reference_tokens = self._tokenize(reference)

        scores = {}
        for n in rouge_types:
            precision, recall, f1 = self._compute_rouge_n(
                candidate_tokens,
                reference_tokens,
                n,
            )
            scores[f'rouge-{n}'] = {
                'precision': precision,
                'recall': recall,
                'f1': f1,
            }

        return scores 