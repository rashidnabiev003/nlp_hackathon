"""Retrieval-specific metrics implementation."""

from typing import List, Optional, Union

import numpy as np


def mean_reciprocal_rank(
    relevance_scores: List[Union[int, float]],
    k: Optional[int] = None,
) -> float:
    """Calculate Mean Reciprocal Rank (MRR).

    Args:
        relevance_scores (List[Union[int, float]]): List of relevance scores (1 for relevant, 0 for not)
        k (Optional[int]): Consider only top-k results

    Returns:
        float: MRR score
    """
    if not relevance_scores:
        return 0.0

    if k is not None:
        relevance_scores = relevance_scores[:k]

    # Find the first relevant document
    for i, score in enumerate(relevance_scores, 1):
        if score > 0:
            return 1.0 / i

    return 0.0


def ndcg(
    relevance_scores: List[Union[int, float]],
    k: Optional[int] = None,
    method: str = 'standard',
) -> float:
    """Calculate Normalized Discounted Cumulative Gain (NDCG).

    Args:
        relevance_scores (List[Union[int, float]]): List of relevance scores
        k (Optional[int]): Calculate NDCG@k
        method (str): Gain calculation method ('standard' or 'exponential')

    Returns:
        float: NDCG score
    """
    if not relevance_scores:
        return 0.0

    if k is not None:
        relevance_scores = relevance_scores[:k]

    # Calculate DCG
    dcg = 0.0
    for i, rel in enumerate(relevance_scores, 1):
        if method == 'exponential':
            gain = 2**rel - 1
        else:
            gain = rel
        dcg += gain / np.log2(i + 1)

    # Calculate IDCG (ideal DCG)
    ideal_scores = sorted(relevance_scores, reverse=True)
    idcg = 0.0
    for i, rel in enumerate(ideal_scores, 1):
        if method == 'exponential':
            gain = 2**rel - 1
        else:
            gain = rel
        idcg += gain / np.log2(i + 1)

    return dcg / idcg if idcg > 0 else 0.0


class RetrievalMetrics:
    """Collection of retrieval-specific metrics."""

    @staticmethod
    def compute_mrr(
        relevance_lists: List[List[Union[int, float]]],
        k: Optional[int] = None,
    ) -> float:
        """Compute average MRR over multiple queries.

        Args:
            relevance_lists (List[List[Union[int, float]]]): List of relevance score lists
            k (Optional[int]): Consider only top-k results

        Returns:
            float: Average MRR score
        """
        if not relevance_lists:
            return 0.0

        mrr_scores = [
            mean_reciprocal_rank(relevance_scores, k)
            for relevance_scores in relevance_lists
        ]
        return float(np.mean(mrr_scores))

    @staticmethod
    def compute_ndcg(
        relevance_lists: List[List[Union[int, float]]],
        k: Optional[int] = None,
        method: str = 'standard',
    ) -> float:
        """Compute average NDCG over multiple queries.

        Args:
            relevance_lists (List[List[Union[int, float]]]): List of relevance score lists
            k (Optional[int]): Calculate NDCG@k
            method (str): Gain calculation method ('standard' or 'exponential')

        Returns:
            float: Average NDCG score
        """
        if not relevance_lists:
            return 0.0

        ndcg_scores = [
            ndcg(relevance_scores, k, method)
            for relevance_scores in relevance_lists
        ]
        return float(np.mean(ndcg_scores)) 