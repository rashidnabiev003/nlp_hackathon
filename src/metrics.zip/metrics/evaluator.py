"""Main evaluator class that combines all metrics."""

from typing import Dict, List, Optional, Union

import numpy as np

from .bert_score import BERTScoreMetric
from .retrieval_metrics import RetrievalMetrics
from .rouge import RougeMetric


class Evaluator:
    """Main evaluator class that combines all metrics."""

    def __init__(
        self,
        bert_model_name: str = 'DeepPavlov/rubert-base-cased',
        rouge_types: List[int] = [1, 2],
    ):
        """Initialize evaluator with all metrics.

        Args:
            bert_model_name (str): Name of the BERT model for BERTScore
            rouge_types (List[int]): N-gram sizes for ROUGE metric
        """
        self.bert_score = BERTScoreMetric(model_name=bert_model_name)
        self.rouge = RougeMetric()
        self.retrieval_metrics = RetrievalMetrics()
        self.rouge_types = rouge_types

    def evaluate_text_similarity(
        self,
        candidates: Union[str, List[str]],
        references: Union[str, List[str]],
    ) -> Dict[str, Union[float, Dict[str, float]]]:
        """Evaluate text similarity using BERTScore and ROUGE.

        Args:
            candidates: Candidate text(s)
            references: Reference text(s)

        Returns:
            Dict[str, Union[float, Dict[str, float]]]: Dictionary with all metrics
        """
        # Compute BERTScore
        bert_scores = self.bert_score.compute_score(candidates, references)

        # Handle single strings vs lists
        if isinstance(candidates, str) and isinstance(references, str):
            # Compute ROUGE scores
            rouge_scores = self.rouge.compute_scores(
                candidates,
                references,
                self.rouge_types,
            )
            return {
                'bert_score': bert_scores,
                'rouge': rouge_scores,
            }
        else:
            # Compute ROUGE scores for each pair
            rouge_scores = [
                self.rouge.compute_scores(cand, ref, self.rouge_types)
                for cand, ref in zip(candidates, references)
            ]
            # Average ROUGE scores
            avg_rouge = {}
            for n in self.rouge_types:
                rouge_n = f'rouge-{n}'
                avg_rouge[rouge_n] = {
                    metric: np.mean([
                        scores[rouge_n][metric]
                        for scores in rouge_scores
                    ])
                    for metric in ['precision', 'recall', 'f1']
                }
            return {
                'bert_score': np.mean(bert_scores),
                'rouge': avg_rouge,
            }

    def evaluate_retrieval(
        self,
        relevance_lists: List[List[Union[int, float]]],
        k: Optional[int] = None,
    ) -> Dict[str, float]:
        """Evaluate retrieval performance using MRR and NDCG.

        Args:
            relevance_lists (List[List[Union[int, float]]]): List of relevance score lists
            k (Optional[int]): Consider only top-k results

        Returns:
            Dict[str, float]: Dictionary with retrieval metrics
        """
        mrr = self.retrieval_metrics.compute_mrr(relevance_lists, k)
        ndcg = self.retrieval_metrics.compute_ndcg(relevance_lists, k)

        return {
            'mrr': mrr,
            'ndcg': ndcg,
        } 