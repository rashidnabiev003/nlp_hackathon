"""BERTScore implementation for semantic similarity evaluation."""

from typing import List, Tuple, Union

import torch
from transformers import AutoModel, AutoTokenizer


class BERTScoreMetric:
    """BERTScore metric for semantic similarity evaluation."""

    def __init__(
        self,
        model_name: str = 'DeepPavlov/rubert-base-cased',
        device: str = 'cuda' if torch.cuda.is_available() else 'cpu',
    ):
        """Initialize BERTScore metric.

        Args:
            model_name (str): Name of the BERT model to use
            device (str): Device to use for computation
        """
        self.device = device
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModel.from_pretrained(model_name).to(device)
        self.model.eval()

    def _get_embeddings(self, text: str) -> torch.Tensor:
        """Get BERT embeddings for text.

        Args:
            text (str): Input text

        Returns:
            torch.Tensor: Text embeddings
        """
        inputs = self.tokenizer(
            text,
            return_tensors='pt',
            padding=True,
            truncation=True,
            max_length=512,
        ).to(self.device)

        with torch.no_grad():
            outputs = self.model(**inputs)
            # Use CLS token embedding
            embeddings = outputs.last_hidden_state[:, 0, :]

        return embeddings

    def compute_score(
        self,
        candidates: Union[str, List[str]],
        references: Union[str, List[str]],
    ) -> Union[float, List[float]]:
        """Compute BERTScore between candidate and reference texts.

        Args:
            candidates: Candidate text(s)
            references: Reference text(s)

        Returns:
            Union[float, List[float]]: BERTScore(s)
        """
        if isinstance(candidates, str) and isinstance(references, str):
            return self._compute_single_score(candidates, references)

        if isinstance(candidates, list) and isinstance(references, list):
            if len(candidates) != len(references):
                raise ValueError('Candidates and references must have the same length')
            return [
                self._compute_single_score(cand, ref)
                for cand, ref in zip(candidates, references)
            ]

        raise ValueError('Candidates and references must be both strings or both lists')

    def _compute_single_score(self, candidate: str, reference: str) -> float:
        """Compute BERTScore for a single pair of texts.

        Args:
            candidate (str): Candidate text
            reference (str): Reference text

        Returns:
            float: BERTScore
        """
        cand_embeddings = self._get_embeddings(candidate)
        ref_embeddings = self._get_embeddings(reference)

        # Compute cosine similarity
        similarity = torch.nn.functional.cosine_similarity(
            cand_embeddings,
            ref_embeddings,
        )

        return float(similarity.mean().item()) 